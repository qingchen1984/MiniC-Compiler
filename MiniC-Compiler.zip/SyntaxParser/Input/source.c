x=y+2;
if (x>=) z=1;
else z=0;
